import React, { useState } from 'react';
import { Button, InputGroup, Form } from 'react-bootstrap';
import logo from '../../Assets/images/logo.svg'

const AdminLogin = () =>{
    return(
        <div className='adminlogin'>
             <div className='container container-theme'>
                <div className='row justify-content-center mh-100vh align-items-center m-sm-0 m-3'>
                    <div className='shadowbox col-lg-6 col-xl-5 col-md-6 bg-white br-30'>
                            <div className='py-5'>
                                <h3 className=' text-center mb-4'><img src={logo} className="loginicon"/></h3>
                                <h4 className='text-center f-600 mb-4'>Login</h4>
                                <hr className='themehr mb-4 mx-5'/>
                                <div className='px-lg-5 px-3 h-55'>
                                     
                                     <label className='fw-600 mb-3'> Email</label>

                                    <InputGroup className="mb-4">
        <InputGroup.Text id="basic-addon1"><span className='fa fa-envelope'></span></InputGroup.Text>
        <Form.Control
          placeholder="Username"
          aria-label="Username"
          aria-describedby="basic-addon1"
        />
      </InputGroup>


      <label className='fw-600 mb-3'> Password</label>
      <InputGroup className="mb-3">
        <InputGroup.Text ><span className='fa fa-lock'></span></InputGroup.Text>
        <Form.Control placeholder='Enter your password' aria-label="Amount (to the nearest dollar)" type="password"/>
        <InputGroup.Text><span className='fa fa-eye-slash'></span></InputGroup.Text>
      </InputGroup>
                                    
                                  <div className='mt-5 text-center'>
                                       <button className='btn btn-theme aquabtn'>Login</button>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
             </div>
        </div>
    )
}

export default AdminLogin